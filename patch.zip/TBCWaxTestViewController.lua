waxClass{"TBCWaxTestViewController", UITableViewController}

function tableView_cellForRowAtIndexPath(self, tableView, indexPath)
	local cell = self:ORIGtableView_cellForRowAtIndexPath(tableView, indexPath)
	cell:textLabel():setText("" .. (10 - indexPath:row()))
	cell:detailTextLabel():setText("这是来自TBCWaxTestViewController.lua脚本修改的内容")
	cell:textLabel():setTextColor(UIColor:redColor())
	return cell
end
